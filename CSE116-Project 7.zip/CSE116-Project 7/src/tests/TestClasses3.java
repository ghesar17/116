package tests;


import org.junit.Test;
import ratings.Rating;
import ratings.datastructures.LinkedListNode;
import ratings.FileReader;
import ratings.Movie;
import ratings.Song;


import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;


public class TestClasses3 {

    @Test
    public void testReadSongsSingleSong(){
        ArrayList<Song> songs = FileReader.readSongs("data/ratingstest1.csv");
        assertEquals(1,songs.size());

        Song song = songs.get(0);

        String ReviewerID = "597";
        assertEquals(ReviewerID,song.getRatings().getValue().getReviewerID());

        String artist = "pinkpantheress";
        assertEquals(artist,song.getArtist());

        String title = "Take me home";
        assertEquals(title,song.getTitle());

        String SongID = "4CykmPXyJzacASnoxR33ns";
        assertEquals(SongID,song.getSongID());
    }

    @Test
    public void testReadSongsMultipleSongs(){
        ArrayList<Song> songs = FileReader.readSongs("data/ratingstest2.csv");
        assertEquals(1,songs.size());
    }

    @Test
    public void testReadSongsEmptyCSV(){
        ArrayList<Song> empty = new ArrayList<>();
        assertEquals(empty,FileReader.readSongs("afoisdfijsdf"));
    }

    @Test
    public void Song_OnlyOneRating(){
        ArrayList<Song> songs = FileReader.readSongs("data/ratingstest2.csv");
        assertEquals(songs.size(),1);
        Song song = songs.get(0);

        assertEquals(5,song.getRatings().getValue().getRating());

        ArrayList<Song> songs1 = FileReader.readSongs("data/ratingstest1.csv");
        assertEquals(songs1.size(),1);
        Song song1 = songs1.get(0);

        assertEquals(5,song1.getRatings().getValue().getRating());
    }

}
