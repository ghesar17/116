package ratings.datastructures;

import java.io.File;
import java.util.ArrayList;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Arrays;


public class asd {
    public static void main(String[] args){
        ArrayList<String> names = new ArrayList<>(Arrays.asList("Justin,Ghesar,Dylan"));
        ArrayList<String> cast = new ArrayList<>();
        for (String name : names){
            cast.add(name);
        }
        System.out.println(cast);

    }
}
