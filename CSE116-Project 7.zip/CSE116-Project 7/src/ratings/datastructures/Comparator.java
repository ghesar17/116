package ratings.datastructures;

    public class Comparator<T> {
        public boolean compare(T a, T b) {
            return false;
        }
}
